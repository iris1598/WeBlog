set(RESOLV_WRAPPER_LIBRARY /data/data/com.pangbai.weblog/files/usr/lib/libresolv_wrapper.so)
